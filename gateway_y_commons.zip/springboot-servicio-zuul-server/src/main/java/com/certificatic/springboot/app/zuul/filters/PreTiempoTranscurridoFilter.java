package com.certificatic.springboot.app.zuul.filters;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;


@Component
public class PreTiempoTranscurridoFilter extends ZuulFilter{
	

	
	Logger log = LoggerFactory.getLogger(PreTiempoTranscurridoFilter.class);
	
	@Override
	public boolean shouldFilter() {// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		 RequestContext ctx = RequestContext.getCurrentContext();
		 HttpServletRequest request = ctx.getRequest();
		 
		 log.info(String.format("Metodo %s peticion entrando a %s", request.getMethod(), request.getRequestURL().toString()));
		 
		 Long inicio= System.currentTimeMillis();
		 request.setAttribute("tiempoInicio", inicio);
		 return null;
		
		
		
	}

	@Override
	public String filterType() {
		return "pre";
	}

	@Override
	public int filterOrder() {
		
		return 1;
	}
	
	

}
