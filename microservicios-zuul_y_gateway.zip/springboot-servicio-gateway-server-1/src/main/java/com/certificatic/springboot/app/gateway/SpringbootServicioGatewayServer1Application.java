package com.certificatic.springboot.app.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class SpringbootServicioGatewayServer1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootServicioGatewayServer1Application.class, args);
	}

}
