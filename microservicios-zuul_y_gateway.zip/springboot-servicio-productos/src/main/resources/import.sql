INSERT INTO PRODUCTOS(nombre,precio,fecha_registro) VALUES('Samsung',18000,NOW());
INSERT INTO PRODUCTOS(nombre,precio,fecha_registro) VALUES('IPhone',30000,NOW());
INSERT INTO PRODUCTOS(nombre,precio,fecha_registro) VALUES('Huawei',20000,NOW());