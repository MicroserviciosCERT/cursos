package com.certificatic.springboot.app.commons.usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioCommonsUsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
