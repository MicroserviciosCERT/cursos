INSERT INTO `usuarios` (username, password, enabled, nombre, apellido, email) VALUES ('luis','$2a$10$TIBvUfaRfY.vYXLl6QJtN..FB0NvfLj3FkGzq3pmfBtu/vVAa32ia',1, 'Luis', 'Perez','correo@dominio.com');
INSERT INTO `usuarios` (username, password, enabled, nombre, apellido, email) VALUES ('admin','$2a$10$m2OTkzrIRwUXY.e4ZL/uA.byRSNpzMl4oCku4Ip6s4KOXJR8zR3XS',1, 'John', 'Doe','jhon.doe@correo.com');

INSERT INTO `roles` (nombre) VALUES ('ROLE_USER');
INSERT INTO `roles` (nombre) VALUES ('ROLE_ADMIN');

INSERT INTO `usuarios_roles` (usuario_id, role_id) VALUES (1, 1);
INSERT INTO `usuarios_roles` (usuario_id, role_id) VALUES (2, 2);
INSERT INTO `usuarios_roles` (usuario_id, role_id) VALUES (2, 1);