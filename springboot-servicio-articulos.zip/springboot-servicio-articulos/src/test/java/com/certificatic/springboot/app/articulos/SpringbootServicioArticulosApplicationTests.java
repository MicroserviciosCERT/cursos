package com.certificatic.springboot.app.articulos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioArticulosApplicationTests {

	@Test
	void contextLoads() {
	}

}
